import pandas as pd

head = ['author','title','style','integral','time','download','comment','favorite','net']
data = pd.read_csv('E:\demo01\\novel\\novel\spiders\spider.txt',names=head,encoding='gb18030',sep=',')

row_num = data.shape[0]
col_num = data.shape[1]
author_01 = []
title_01 = []
style_01 = []
time_01 = []
integral_01 = []
download_01 = []
comment_01 = []
favorite_01 = []
net_01 = []
for i in range(row_num):
    author_01.append(data['author'][i])
    style_01.append(data['style'][i])
    title_01.append(data['title'][i])
    time_01.append(str(data['time'][i]))
    integral_01.append(str(data['integral'][i]))
    download_01.append(str(data['download'][i]))
    comment_01.append(str(data['comment'][i]))
    favorite_01.append(str(data['favorite'][i]))
    net_01.append(data['net'][i])

def data2dict_10(data):        #dataframe转换为dict 取出前十个
    list_01 = data.to_dict(orient='records')[0:10]
    return list_01

def sort_all():
    col_01 = data.sort_values(by = 'integral',ascending=False)
    dict_01 = data2dict_10(col_01)
    col_02 = data.sort_values(by='download', ascending=False)
    dict_02 = data2dict_10(col_02)
    col_03 = data.sort_values(by='comment', ascending=False)
    dict_03 = data2dict_10(col_03)
    col_04 = data.sort_values(by='favorite', ascending=False)
    dict_04 = data2dict_10(col_04)

    dict_end ={'integral':dict_01,'download':dict_02,'comment':dict_03,'favorite':dict_04}
    return dict_end



if __name__=='__main__':
    print(sort_all())