# import matplotlib.pyplot as plt
# from io import BytesIO
# import base64
#
# def zhexian(title,x_label,y_label,x,y,X=[],Y=[]):
#
#     # 设置绘图风格
#     plt.style.use('ggplot')
#     # 设置中文编码和负号的正常显示
#     plt.rcParams['font.sans-serif'] = [u'SimHei']
#     plt.rcParams['axes.unicode_minus'] = False
#
#     # 设置图框的大小
#     fig = plt.figure(figsize=(x,y))
#     # 绘图
#     plt.plot(X, # x轴数据
#              Y, # y轴数据
#              linestyle = '-', # 折线类型
#              linewidth = 2, # 折线宽度
#              color = 'steelblue', # 折线颜色
#              marker = 'o', # 点的形状
#              markersize = 6, # 点的大小
#              markeredgecolor='black', # 点的边框色
#              markerfacecolor='brown') # 点的填充色
#
#     # 添加标题和坐标轴标签
#     plt.title(title)
#     plt.xlabel(x_label)
#     plt.ylabel(y_label)
#
#     # 剔除图框上边界和右边界的刻度
#     plt.tick_params(top = 'off', right = 'off')
#
#     # 为了避免x轴日期刻度标签的重叠，设置x轴刻度自动展现，并且45度倾斜
#     fig.autofmt_xdate(rotation = 45)  # 设置x轴外观
#
#     # figure 保存为二进制文件
#     buffer = BytesIO()
#     plt.savefig(buffer)
#     plot_data = buffer.getvalue()
#
#     # 图像数据转化为 HTML 格式
#     imb = base64.b64encode(plot_data)
#     ims = imb.decode()
#
#
#     return ims
#
# def zhuzhuang(title,x_label,y_label,x,y,X=[],Y=[]):
#
#     # 设置绘图风格
#     plt.style.use('ggplot')
#     # 设置中文编码和负号的正常显示
#     plt.rcParams['font.sans-serif'] = [u'SimHei']
#     plt.rcParams['axes.unicode_minus'] = False
#
#     # 设置图框的大小
#
#     fig = plt.figure(figsize=(x,y))
#     bar_width = 0.35  # 定义一个数字代表每个独立柱的宽度
#
#     plt.bar(X, Y, width=bar_width, color='b')
#
#     plt.title(title)
#     plt.xlabel(x_label)
#     plt.ylabel(y_label)
#     plt.tick_params(top='off', right='off')
#     fig.autofmt_xdate(rotation=45)
#
#     # figure 保存为二进制文件
#     buffer = BytesIO()
#     plt.savefig(buffer)
#     plot_data = buffer.getvalue()
#
#     # 图像数据转化为 HTML 格式
#     imb = base64.b64encode(plot_data)
#     ims = imb.decode()
#
#     return ims
#
# def bingzhuang(title,x_label,y_label,x,y,X=[],Y=[]):
#
#     # 设置绘图风格
#     plt.style.use('ggplot')
#     # 设置中文编码和负号的正常显示
#     plt.rcParams['font.sans-serif'] = [u'SimHei']
#     plt.rcParams['axes.unicode_minus'] = False
#
#     # 设置图框的大小
#     fig = plt.figure(figsize=(x,y))
#     # 绘图
#     plt.pie(Y,labels=X,shadow=True)
#
#     # 添加标题和坐标轴标签
#     plt.title(title)
#     plt.xlabel(x_label)
#     plt.ylabel(y_label)
#
#     # 剔除图框上边界和右边界的刻度
#     plt.tick_params(top = 'off', right = 'off')
#     plt.legend()
#     fig.autofmt_xdate(rotation=45)
#
#
#     # figure 保存为二进制文件
#     buffer = BytesIO()
#     plt.savefig(buffer)
#     plot_data = buffer.getvalue()
#
#
#     # 图像数据转化为 HTML 格式
#     imb = base64.b64encode(plot_data)
#     ims = imb.decode()
#
#     return ims
#
#
# if __name__=='__main__':
#     l = ['2017', '2018', '2019', '2020', '2021']
#     m = [3,2,1,5,8]
#     bingzhuang('年份与作品数量','年份','作品数量',5,5,l,m)


