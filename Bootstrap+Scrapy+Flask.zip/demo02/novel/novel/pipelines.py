# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
from sqlalchemy import Column, String, create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base


class NovelPipeline(object):
    def open_spider(self, spider):
        self.fo = open('spider.txt', 'a')

    def process_item(self, item, spider):
         data = "{},{},{},{},{},{},{},{},{}\n".format(item['author'], item['title'], item['style'], item['integral'], item['time'], item['download'],item['comment'],item['favorite'],item['net'])
         self.fo.write(data)
         return item

    def close_spider(self, spider):
        self.fo.close()


Base = declarative_base()

class Book(Base):
    # 表的名字:
    __tablename__ = 'books'

    # 表的结构:
    author = Column(String)
    title = Column(String, primary_key=True)
    style = Column(String)
    time = Column(String)
    net = Column(String)

    # 初始化数据库连接:
    engine = create_engine('sqlite:///book')
    # 创建DBSession类型:
    DBSession = sessionmaker(bind=engine)
    # 创建session对象:
    session = DBSession()

    def add(author,title,style,time,net):
        new_book = Book(author = author,title = title ,style = style,time = time,net = net)
        # 创建新User对象:
        # 添加到session:
        Book.session.add(new_book)
        # 提交即保存到数据库:
        Book.session.commit()
        # 关闭session:
        Book.session.close()
