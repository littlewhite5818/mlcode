# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class NovelItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    author = scrapy.Field()  # 作者
    title = scrapy.Field()  # 作品
    style = scrapy.Field()  # 风格
    integral = scrapy.Field()  # 积分
    time = scrapy.Field()
    download = scrapy.Field()  #下载数
    comment = scrapy.Field()  #评论数
    favorite = scrapy.Field()  #收藏数
    net = scrapy.Field()  #作品链接