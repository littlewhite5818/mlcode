# -*- coding: utf-8 -*-
import scrapy
from scrapy import Request
import re
from novel.items import NovelItem


class NovelspiderSpider(scrapy.Spider):
    name = 'novelSpider'
    allowed_domains = ['jjwxc.net']
    start_urls = ['http://www.jjwxc.net/bookbase_slave.php?orderstr=2']
    page=1


    def parse(self, response):

        selectors=response.xpath('/html/body/div[7]/table/tbody/tr[position()>1 and position()<53]')
        i = 1
        for selector in selectors:

            item = NovelItem()
            print('分析第'+str(self.page)+'页，第'+str(i)+'个小说')
            item['author'] = selector.xpath('./td[1]/a/text()').extract()[0]
            item['title'] = selector.xpath('./td[2]/a/text()').extract()[0]
            style = selector.xpath('./td[3]/text()').extract()[0]
            style=style.strip()
            item['style'] = style
            item['integral'] = selector.xpath('./td[7]/text()').extract()[0]
            time= selector.xpath('./td[8]/text()').extract()[0]
            time=time[0:4]
            item['time']=time
            i += 1
            detail_url = selector.xpath('./td[2]/a/@href').extract()
            detail_url = 'http://www.jjwxc.net/' + detail_url[0]
            item['net'] = detail_url
            yield Request(detail_url, callback=self.details, meta={'item':item})

        if self.page<1:
            self.page += 1
            next_url = response.xpath('/html/body/div[8]/span[2]/a/@href').extract()
            next_url = 'http://www.jjwxc.net/' + next_url[0]
            yield Request(next_url, callback=self.parse)

    def details(self,response):
        item = response.meta['item']
        download = response.xpath('/html/body/table[@id=\'oneboolt\']/tbody/tr[last()]/td/div/text()[1]').extract()[0]
        download=re.sub('\D','',download)
        item['download'] = download
        item['comment'] = response.xpath('/html/body/table[@id=\'oneboolt\']/tbody/tr[last()]/td/div/span[2]/text()[1]').extract()[0]
        item['favorite'] = response.xpath('/html/body/table[@id=\'oneboolt\']/tbody/tr[last()]/td/div/span[3]/text()[1]').extract()[0]
        yield item



