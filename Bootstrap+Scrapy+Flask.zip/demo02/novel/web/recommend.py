from web.orderdata import Order
from web.bookdata import Book

def recommend(name):
    title = Order.query_all(name) #根据用户名，查询已订阅图书
    begin = []
    end = []
    book = []
    buffer = []
    for i in title:        #根据标题，查询图书风格
        begin.append(Book.query_title_02(i))
    for i in begin:        #去重
        if not i in end:
            end.append(i)
    for i in end:      # end是处理最终得到的所有图书风格
        buffer = (Book.query_style_01(i))
        while buffer:
            book.append(buffer.pop())
    print(book)

    res = {'res':book}
    return res


if __name__=='__main__':
    recommend('jack')