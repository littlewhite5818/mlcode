from flask import Flask, request, render_template,flash,jsonify,redirect
from web.database import User
from web.bookdata import Book
from  web.orderdata import Order
import web.recommend as recom

app = Flask(__name__)
app.config['SECRET_KEY'] = 'jiushigan'
# imgs01 = dp.imgs2base64_01()
# imgs02 = dp.imgs2base64_02()
# imgs03 = dp.imgs2base64_03()
user_now = []

@app.route('/', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        # 获取请求中的数据
        username = request.form.get('name')
        password = request.form.get('password')
        if (username and password):
            if User.exist(username,password):
                flash('用户名已存在')
                return render_template('register.html')
            User.add(username,password)
            flash('注册成功')
            return render_template('signin.html')
    return render_template('register.html')

@app.route('/signin', methods=['GET','POST'])
def signin():
    if request.method == 'POST':
        # 获取请求中的数据
        username = request.form.get('name')
        password = request.form.get('password')
        if (User.equl(username, password) == 1):
            user_now.append(username)
            flash('登陆成功')
            return render_template('home.html')
        flash('用户名或密码错误')
        return render_template('signin.html')
    return render_template('signin.html')

@app.route('/home', methods=['GET','POST'])
def home():
    res = Book.query_all()
    return render_template('home.html', **res)


@app.route('/order', methods=['GET','POST'])
def test():
    order = request.values['order']
    user = user_now[-1]
    Order.add(user,order)
    return jsonify({'order':order})

@app.route('/cancel', methods=['GET','POST'])
def cancel():
    order = request.values['order']
    user = user_now[-1]
    Order.delete(user,order)
    return redirect('http://127.0.0.1:5000/book')

@app.route('/recommend', methods=['GET','POST'])
def rec():
    user = user_now[-1]
    res = recom.recommend(name=user)
    return render_template('recommend.html',**res,user = user)

@app.route('/book', methods=['GET','POST'])
def test_01():
    user = user_now[-1]
    begin = []
    title = Order.query_all(user)
    for i in title:
        begin.append(Book.query_title(i))
    orde = {'orde':begin}
    return render_template('order.html',**orde,user = user)


@app.route('/author', methods=['GET','POST'])
def author():
    return render_template('author.html')

@app.route('/style', methods=['GET','POST'])
def style():
    return render_template('style.html')

@app.route('/year', methods=['GET','POST'])
def year():
    return render_template('year.html')

@app.route('/admin', methods=['GET','POST'])
def admin():
    if request.method == 'POST':
        # 获取请求中的数据
        key = request.form.get('key')
        if (key == '112233'):
            flash('管理员你好')
            return render_template('admin_sys.html')
        flash('你不是管理员')
        return render_template('admin.html')
    return render_template('admin.html')

@app.route('/search', methods=['GET','POST'])
def recommend():
    if request.method == 'POST':
        author_rec = request.form.get('author')
        style_rec = request.form.get('style')
        title_rec = request.form.get('title')
        time_rec = request.form.get('time')
        if author_rec:
            res = Book.query_author(author_rec)
            return render_template('search.html',**res)
        if style_rec:
            res = Book.query_style(style_rec)
            return render_template('search.html',**res)
        if title_rec:
            res = Book.query_title_01(title_rec)
            return render_template('search.html',**res)
        if time_rec:
            res = Book.query_time(time_rec)
            return render_template('search.html',**res)
    return render_template('search.html')

@app.route('/add', methods=['GET','POST'])
def add():
    if request.method == 'POST':
        aut = request.form.get('author')
        tit = request.form.get('title')
        sty = request.form.get('style')
        inte = request.form.get('integral')
        tim = request.form.get('time')
        down = request.form.get('download')
        fav = request.form.get('favorite')
        com = request.form.get('comment')
        net = request.form.get('net')
        Book.add(aut,tit,sty,inte,tim,down,com,fav,net)
        flash('添加成功')
    return render_template('admin_sys.html')
@app.route('/del', methods=['GET','POST'])
def dele():
    if request.method == 'POST':
        tit = request.form.get('title')
        Book.delete(tit)
        flash('删除成功')
    return render_template('admin_sys.html')


if __name__ == '__main__':
    app.run(debug=True)