# 导入:
from sqlalchemy import Column, String, create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base

# 创建对象的基类:
Base = declarative_base()

# 定义Book对象:
class Book(Base):
    # 表的名字:
    __tablename__ = 'books'

    # 表的结构:
    author = Column(String)
    title = Column(String, primary_key=True)
    style = Column(String)
    integral = Column(String)
    time = Column(String)
    download = Column(String)
    comment = Column(String)
    favorite = Column(String)
    net = Column(String)

    # 初始化数据库连接:
    engine = create_engine('sqlite:///book')
    # 创建DBSession类型:
    DBSession = sessionmaker(bind=engine)
    # 创建session对象:
    session = DBSession()

    def add(author,title,style,integral,time,download,comment,favorite,net):
        new_book = Book(author = author,title = title ,style = style,integral = integral,time = time,download = download,comment = comment,favorite = favorite,net = net)
        # 创建新User对象:
        # 添加到session:
        Book.session.add(new_book)
        # 提交即保存到数据库:
        Book.session.commit()
        # 关闭session:
        Book.session.close()
    def delete(title):
        Book.session.query(Book).filter(Book.title ==title).delete()
        # 创建新User对象:
        # 添加到session:
        # Book.session.delete(old_book)
        # 提交即保存到数据库:
        Book.session.commit()
        # 关闭session:
        Book.session.close()


    def query_style(style):
        begin = []
        for que in  Book.session.query(Book).filter(Book.style.like('%'+style+'%')).all():
            res = {'author': que.author, 'title': que.title, 'style': que.style, 'time': que.time, '链接': que.net}
            begin.append(res)
        end = {'res': begin}
        Book.session.close()
        return end
    def query_style_01(style):
        begin = []
        for que in  Book.session.query(Book).filter(Book.style == style,).all():
            res = {'author': que.author, 'title': que.title, 'style': que.style, 'time': que.time, '链接': que.net}
            begin.append(res)
        Book.session.close()
        return begin

    def query_author(author):
        begin = []
        for que in Book.session.query(Book).filter(Book.author.like('%'+author+'%')).all():
            res = {'author': que.author, 'title': que.title, 'style': que.style, 'time': que.time, '链接': que.net}
            begin.append(res)
        end = {'res': begin}
        Book.session.close()
        return end

    def query_title(tilte):
        for que in Book.session.query(Book).filter(Book.title.like('%'+tilte+'%')).all():
            res = {'author': que.author, 'title': que.title, 'style': que.style, 'time': que.time, '链接': que.net}
        Book.session.close()
        return res
    def query_title_01(tilte):
        begin = []
        for que in Book.session.query(Book).filter(Book.title.like('%'+tilte+'%')).all():
            res = {'author': que.author, 'title': que.title, 'style': que.style, 'time': que.time, '链接': que.net}
            begin.append(res)
        end = {'res':begin}
        Book.session.close()
        return end

    def query_title_02(tilte):
        book = Book.session.query(Book).filter(Book.title == tilte).first()
        Book.session.close()
        return book.style

    def query_time(time):
        begin = []
        for que in Book.session.query(Book).filter(Book.time == time).all():
            res = {'author':que.author,'title':que.title,'style':que.style,'time':que.time,'链接':que.net}
            begin.append(res)
        end = {'res':begin}
        Book.session.close()
        return end

    def query_all():
        begin = []
        for que in Book.session.query(Book).filter().all():
            res = {'author': que.author, 'title': que.title, 'style': que.style, 'time': que.time,'integral':que.integral,'download':que.download, '链接': que.net}
            begin.append(res)
        end = {'res': begin}
        Book.session.close()
        return end





if __name__=='__main__':
     # Book.add('青山','柯南','侦探','1235648','2020','5265','12032','11111','https://www.baidu.com/')
     # Book.delete('柯南')
     print(Book.query_style_01('原创-纯爱-近代现代-爱情'))