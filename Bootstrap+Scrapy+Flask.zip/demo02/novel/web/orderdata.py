# 导入:
from sqlalchemy import Column, String, create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
import datetime

# 创建对象的基类:
Base = declarative_base()

# 定义Book对象:
class Order(Base):
    # 表的名字:
    __tablename__ = 'order'

    # 表的结构:
    id = Column(String, primary_key=True)
    name = Column(String)
    title = Column(String)


    # 初始化数据库连接:
    engine = create_engine('sqlite:///db')
    # 创建DBSession类型:
    DBSession = sessionmaker(bind=engine)
    # 创建session对象:
    session = DBSession()

    def add(name,title):
        if Order.exist(name,title):
            now = datetime.datetime.now()
            new_order = Order(id = now,name = name, title = title)
            Order.session.add(new_order)
            Order.session.commit()
            Order.session.close()
        print('已订阅')
            # 关闭session:
        Order.session.close()



    def exist(name,title):
        # 创建Query查询，filter是where条件，最后调用one()返回唯一行，如果调用all()则返回所有行:
        new_order = Order.session.query(Order).filter(Order.name == name,Order.title == title).all()
        #打印类型和对象的name属性:
        if (new_order ==[]):
            Order.session.close()
            return 1                     #可以订阅
        else:
            Order.session.close()         #已经订阅
            return 0

    # def query_all(name):
    #     begin = []
    #     for que in Order.session.query(Order).filter(Order.name == name).all():
    #         res = {'id': que.id, 'name': que.name, 'title': que.title}
    #         begin.append(res)
    #     end = {'res': begin}
    #     Order.session.close()
    #     return end


    def query_all(name):
        begin = []
        for que in Order.session.query(Order).filter(Order.name == name).all():
            begin.append(que.title)
        Order.session.close()
        return begin
    def delete(name,title):
        if (Order.exist(name,title)==0):
            Order.session.query(Order).filter(Order.name==name,Order.title==title).delete()
            print('已取消订阅')
            Order.session.commit()
            Order.session.close()

if __name__ == '__main__':
    print(Order.query_all('jack'))
