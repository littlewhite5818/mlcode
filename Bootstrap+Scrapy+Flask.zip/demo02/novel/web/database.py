# 导入:
from sqlalchemy import Column, String, create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base

# 创建对象的基类:
Base = declarative_base()

# 定义User对象:
class User(Base):

    # 表的名字:
    __tablename__ = 'users'

    # 表的结构:
    name = Column(String(20), primary_key=True)
    pwd = Column(String(20))
    # 初始化数据库连接:
    engine = create_engine('sqlite:///db')
    # 创建DBSession类型:
    DBSession = sessionmaker(bind=engine)
    # 创建session对象:
    session = DBSession()
    def add(name,pwd):
        # 创建新User对象:
        new_user = User(name =name , pwd = pwd)
        # 添加到session:
        User.session.add(new_user)
        # 提交即保存到数据库:
        User.session.commit()
        # 关闭session:
        User.session.close()

    def exist(name,pwd):
        # 创建Query查询，filter是where条件，最后调用one()返回唯一行，如果调用all()则返回所有行:
        user = User.session.query(User).filter(User.name == name).all()
        #打印类型和对象的name属性:
        if (user ==[]):
            User.session.close()
            return 0                     #可以注册
        else:
            User.session.close()         #不能注册
            return 1
    def equl(name,pwd):
        # 创建Query查询，filter是where条件，最后调用one()返回唯一行，如果调用all()则返回所有行:
        user = User.session.query(User).filter(User.name == name , User.pwd == pwd).all()
        # 打印类型和对象的name属性:
        if (user ==[]):
            User.session.close()
            return 0                    #不能登录
        else:
            User.session.close()         #可以登录
            return 1


class Admin(Base):

    # 表的名字:
    __tablename__ = 'admin'

    # 表的结构:
    id = Column(String(20), primary_key=True)
    pwd = Column(String(20))
    # 初始化数据库连接:
    engine = create_engine('sqlite:///db')
    # 创建DBSession类型:
    DBSession = sessionmaker(bind=engine)
    # 创建session对象:
    session = DBSession()

    def equl(name,pwd):
        # 创建Query查询，filter是where条件，最后调用one()返回唯一行，如果调用all()则返回所有行:
        admin = Admin.session.query(User).filter(Admin.name == name , Admin.pwd == pwd).all()
        # 打印类型和对象的name属性:
        if (admin ==[]):
            User.session.close()
            return 0                    #不能登录
        else:
            User.session.close()         #可以登录
            return 1

if __name__=='__main__':
    print(User.equl('jack','123'))
    print(User.exist('jack','123'))
    print(User.equl('ooo','888'))
    print(User.exist('ooo','123'))
